Arduino communicating with Node.js
To make this work you will need to download the socket.io and serialPort
modules in the node_modules folder. 

The application is run by executing index.js (node index.js)

